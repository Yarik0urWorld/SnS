#include <stdlib.h>
#include <GL/glut.h>

float movement = 0.0f;
float angle = 0.0f;

void mdl_snowmanBody();
void mdl_snowmanHead();

void changeSize(int w, int h) {
	if (h == 0)
		h = 1;
	float ratio =  w * 1.0f / h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glViewport(0, 0, w, h);

	gluPerspective(45.0f, ratio, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
}

void testCube() {
	glBegin(GL_QUADS);            // Begin drawing the color cube with 6 quads
                                  // Top face (y = 1.0f)
                                  // Define vertices in counter-clockwise (CCW) order with normal pointing out
		glColor3f(0.0f, 1.0f, 0.0f);     // Green
		glVertex3f(1.0f, 1.0f, -1.0f);
		glVertex3f(-1.0f, 1.0f, -1.0f);
		glVertex3f(-1.0f, 1.0f, 1.0f);
		glVertex3f(1.0f, 1.0f, 1.0f);

		// Bottom face (y = -1.0f)
		glColor3f(1.0f, 0.5f, 0.0f);     // Orange
		glVertex3f(1.0f, -1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(1.0f, -1.0f, -1.0f);

		// Front face  (z = 1.0f)
		glColor3f(1.0f, 0.0f, 0.0f);     // Red
		glVertex3f(1.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);
		glVertex3f(1.0f, -1.0f, 1.0f);

		// Back face (z = -1.0f)
		glColor3f(1.0f, 1.0f, 0.0f);     // Yellow
		glVertex3f(1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, 1.0f, -1.0f);
		glVertex3f(1.0f, 1.0f, -1.0f);

		// Left face (x = -1.0f)
		glColor3f(0.0f, 0.0f, 1.0f);     // Blue
		glVertex3f(-1.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, 1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);

		// Right face (x = 1.0f)
		glColor3f(1.0f, 0.0f, 1.0f);     // Magenta
		glVertex3f(1.0f, 1.0f, -1.0f);
		glVertex3f(1.0f, 1.0f, 1.0f);
		glVertex3f(1.0f, -1.0f, 1.0f);
		glVertex3f(1.0f, -1.0f, -1.0f);
	glEnd();  // End of drawing color-cube
}

void renderScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0.6f, 0.85f, 0.91f, 1.0f);

	angle += movement;
	
	glLoadIdentity();
	gluLookAt(5.5f, 5.5f, 5.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
	
	glRotatef(angle, 0.0f, 1.0f, 0.0f);
	//~ testCube();
	mdl_snowmanBody();
	glTranslatef(0.0f, 1.0f, 0.0f);
	mdl_snowmanHead();
	
	glutSwapBuffers();

}

void pressNormalKey(unsigned char c, int x, int y) {
	switch(c) {
		case 'a':
			movement = 0.5f;
			break;
		case 'd':
			movement = -0.5f;
			break;
		case 'q':
			exit(0);
	}
}

void releaseNormalKey(unsigned char c, int x, int y) {
	switch(c) {
		case 'a':
		case 'd':
			movement = -0.0f;
			break;
	}
}

#ifdef _WIN32
int WinMain(HINSTANCE a, HINSTANCE b, char *c, int d)
#else
int main()
#endif
{
	char **argv = (char **)malloc(sizeof(char *));
	*argv = (char *)malloc(sizeof(char));
	**argv = '\0';
	int argc = 1;

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(400,400);
	glutCreateWindow("Model draw tool");

	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);
	//~ glutSpecialFunc(pressKey);
    glutKeyboardFunc(pressNormalKey);
    
    glutSetCursor(GLUT_CURSOR_NONE);
    
	glutIgnoreKeyRepeat(1);
	//~ glutSpecialUpFunc(releaseKey);
    glutKeyboardUpFunc(releaseNormalKey);

    //~ t_begin = gettime();

	glEnable(GL_DEPTH_TEST);
 	// glEnable(GL_TEXTURE_2D);
        
	glutMainLoop();
 
	return 1;
}
