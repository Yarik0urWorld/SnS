#ifndef _ASSETS_H
#define _ASSETS_H

// Assets (don't exist at the moment)
//~ void loadTexture();

//~ _Bool textureLoaded = 0;
//~ GLuint texture;

#endif
