#ifndef _BULLET_H
#define _BULLET_H

// Bullet logic
void resetBullet();
void shoot();

// Bullet drawing
void drawBullet();

#endif
