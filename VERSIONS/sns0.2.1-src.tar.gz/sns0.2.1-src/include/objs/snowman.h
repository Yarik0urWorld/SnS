#ifndef _SNOWMAN_H
#define _SNOWMAN_H

// Snowmen logic
void resetSnowmanMatrix();

// Snowmen drawing
void drawSnowMan(long);
long *collidesSnowman(float, float);

#endif
