#ifndef _APPEARANCE_H
#define _APPEARANCE_H

// Appearance
void renderScene();

#endif
