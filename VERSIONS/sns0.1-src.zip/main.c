#ifdef _WIN32
#   include <windows.h>
#   define GLUT_DISABLE_ATEXIT_HACK
#else
#   include <stdlib.h>
#   include <time.h>
#   include <sys/time.h>
#   include <inttypes.h>
#endif

// Idk if _USE_MATH_DEFINES does somethig on Linux
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "Instructions_image.h"


// Movement
#define SPEED 180.0f
#define RSPEED 3.0f
#define EYE_Y 1.0f

// Gun
#define GUN_ROT M_PI_4 / 3
#define GUNRELOAD_MAX 0.1f
#define GUNRELOAD_TIME 0.16f
#define GUN_DAMAGE 1

// Bullet
#define BULLET_Y EYE_Y - 0.3f
#define BULLET_SPEED 60.0f
#define BULLET_MAX_DIST 20.0f
#define DYNASBF_Q 50                 // DynaSBF = Dynamic SBF; SBF = Smooth Bullet Flight

// Snowman
#define SNOWMAN_MATRIX_SIZE_X 10
#define SNOWMAN_MATRIX_SIZE_Z 10
#define SNOWMAN_MATRIX_DENSITY 5
#define SNOWMAN_RADIUS 1.0f
#define SNOWMAN_MAX_HP 3

// Snowman model
#define SNOWMAN_HEAD_MIN_HEIGHT 0.75f

// Arrow model
#define ARROW_SIZE 0.02f
#define ARROW_LENGTH 1.5f
#define ARROWHEAD_Z 0.2f
#define ARROWHEAD_XS 0.1f
#define ARROWHEAD_YS 0.03f

// Bow model
#define BOW_THICKNESS 0.03f
#define BOWBODY_FRONT_LN 0.3f
#define BOWBODY_CURVE_OFFSET 0.2f
#define BOWBODY_CURVE_LN 0.7f
#define BOW_HOLE_THICKNESS 0.025f
#define BOWSPRING_MAX_TENSION 0.2f

// Misc
#define FONT GLUT_BITMAP_8_BY_13
#define BUF_SZ 256

#define DEBUG_FEATURES

#ifdef _WIN32
typedef DWORD S_uint32_t;
#else
typedef uint32_t S_uint32_t;
#endif

#define RADTODEG(x) ((x) * 57.29577951308232)

typedef struct _ {
    float x, z, lx, lz, flew, angle;
    _Bool enabled;
} bullet_t;

float angle = 0.0;
float lx = 0.0f, lz = -1.0f;
float x = SNOWMAN_MATRIX_SIZE_X * SNOWMAN_MATRIX_DENSITY / 2, z = SNOWMAN_MATRIX_SIZE_Z * SNOWMAN_MATRIX_DENSITY / 2;
float deltaAngle = 0.0f;
float deltaMove = 0;
float gunReload = 0.0f;
bullet_t bullet;
long snowmanMatrix[SNOWMAN_MATRIX_SIZE_Z][SNOWMAN_MATRIX_SIZE_X];
_Bool helpOpened = 0;
_Bool textureLoaded = 0;
GLuint texture;
double t_begin = 0, frame_begin = 0, tpf = 0.16f;
unsigned char buf[BUF_SZ];
int width, height;
S_uint32_t DynaSBF_degree = 1;
void *bin;                      // IF killer

#ifdef DEBUG_FEATURES
_Bool upperView = 0;
#endif

void shoot();
void resetSnowmanMatrix();
void resetBullet();
void drawString(const unsigned char *, float, float);
void loadTexture();
double gettime();
float _square(float);
void changeSize(int, int);
void computePos(float);
void computeDir(float);
void drawGun();
void gunLogic();
void drawBullet();
void bulletStep();
void bulletLogic();
void renderScene();
void pressKey(int, int, int);
void releaseKey(int, int, int);
void pressNormalKey(unsigned char, int, int);
void releaseNormalKey(unsigned char, int, int);
long *collidesSnowman(float, float);
void fixPosition();

#ifdef _WIN32
double gettime() {
    FILETIME ft;
    
    GetSystemTimeAsFileTime(&ft);
    
    return (double)((ft.dwHighDateTime & 0x7f) << 25 | ft.dwLowDateTime >> 7) / 78125;
}
#else
double gettime() {
    struct timeval t;

    gettimeofday(&t, 0)
;
    return ((double)t.tv_usec)/ 1000000 + t.tv_sec;
}
#endif
void loadTexture() {
    if (!textureLoaded) {
        glGenTextures(1, &texture);
        glBindTexture(GL_TEXTURE_2D, texture);
        
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Instructions_width, Instructions_height, 0, GL_RGB, GL_UNSIGNED_BYTE, Instructions);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        
        glBindTexture(GL_TEXTURE_2D, 0);
        
        textureLoaded = 1;
        printf("Loaded instructions\n");
    }
}

// Optimization. pow(n, 2) from <math.h> might be slower
float _square(float n) {
    return n * n;
}

void changeSize(int w, int h) {
	if (h == 0)
		h = 1;
	float ratio =  w * 1.0 / h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glViewport(0, 0, w, h);

	gluPerspective(45.0f, ratio, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);

    width = w;
    height = h;
}
 
void drawSnowMan(long health) {
#ifdef STAB_IFS
    if (health <= 0) return;
#endif

 	glColor3f(1.0f, 1.0f, 1.0f);
 	
    // Snowman's body
	glTranslatef(0.0f ,0.75f, 0.0f);
	glutSolidSphere(0.75f,20,20);
 	
    // Snowman's head
	glTranslatef(0.0f, 1.0f * ( ((float) health - 1) / (SNOWMAN_MAX_HP - 1) * (1 - SNOWMAN_HEAD_MIN_HEIGHT) + SNOWMAN_HEAD_MIN_HEIGHT), 0.0f);
	glutSolidSphere(0.25f,20,20);
	
    // Snowman's eyes
	glPushMatrix();
	glColor3f(0.0f,0.0f,0.0f);
	glTranslatef(0.05f, 0.10f, 0.18f);
	glutSolidSphere(0.05f,10,10);
	glTranslatef(-0.1f, 0.0f, 0.0f);
	glutSolidSphere(0.05f,10,10);
	glPopMatrix();
    
	// Snowman's nose
	glColor3f(1.0f, 0.5f , 0.5f);
	//glRotatef(0.0f,1.0f, 0.0f, 0.0f);
	glutSolidCone(0.08f,0.5f,10,2);
}

void computePos(float deltaMove) {
    register float x1 = x + deltaMove * lx * 0.1f, z1 = z + deltaMove * lz * 0.1f;
	
    if (collidesSnowman(x1, z1) == bin) {
        x = x1; z = z1;
    }
}
 
void computeDir(float deltaAngle) {
	angle += deltaAngle;
	lx = sin(angle);
	lz = -cos(angle);
}

void drawGun() {
    glPushMatrix();
    
    computeDir(GUN_ROT);
    glTranslatef(x + lx, EYE_Y - 0.3f, z + lz);
    computeDir(-GUN_ROT);
    glRotatef(180.0f - RADTODEG(angle), 0.0f, 1.0f, 0.0f);
    glRotatef(85.0f, 0.0f, 0.0f, -1.0f);
    
   
    //~ glutSolidCone(0.15f, 0.5f, 30, 2);
    
    /*        ________
     *  _____/ __o___ \______ 
     * |______/------\_______|
     */
    
    /*        
     *  
     *         ------
     */


    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET                                                      );
        glVertex3f( 0.0f            ,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET - BOWSPRING_MAX_TENSION * (gunReload / GUNRELOAD_MAX));
        glVertex3f( 0.0f            ,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET - BOWSPRING_MAX_TENSION * (gunReload / GUNRELOAD_MAX));
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET                                                      );
    glEnd();

    glColor3f(0.58f, 0.32f, 0.0f);

    // Very hard...
    glBegin(GL_QUADS);
        
        // -----------------------
        //        UPPER PART
        // -----------------------        
    
        /*        ________
         *        ________ 
         * (upper)
         */
    
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        
        /*
         *               ________ 
         *               \_______|
         * (upper)
         */
    
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       );
        
        /*  
         *  _______ 
         * |______/
         * (upper)
         */
        
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       );
        
        // -----------------------
        //        LOWER PART
        // -----------------------  
        
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       );
        
        /*        ________
         *        ________ 
         * (lower)
         */
    
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        
        /*
         *               ________ 
         *               \_______|
         * (lower)
         */
    
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f( BOWBODY_CURVE_LN, -BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       );
        
        /*  
         *  _______ 
         * |______/
         * (lower)
         */
         
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       );
        
        // -----------------------
        //        "WALLS"
        // -----------------------
        
        /*        
         *         ______
         * 
         */
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        
        /*  
         *  
         *  ______
         */
        
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       ); 
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       ); 
        
        /*
         *
         *                _______
         */
         
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       ); 
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       ); 
    glEnd();
    
    glPopMatrix();
}

void gunLogic() {
    if (gunReload > 0.0f) {
        gunReload -= GUNRELOAD_MAX / GUNRELOAD_TIME * tpf;
        
        if (gunReload < 0.0f) gunReload = 0.0f; // oops, we did too much :o)
    }
}

void drawBullet() {
    if (!bullet.enabled) return;
    
    glPushMatrix();
    
    glTranslatef(bullet.x, BULLET_Y, bullet.z);
    glRotatef(180 - RADTODEG(bullet.angle), 0.0f, 1.0f, 0.0f);
        
    glColor3f(0.45f, 0.29f, 0.19f);
    
    // Arrow body
    
    /* /\
     * \/
     */
    glBegin(GL_QUADS);
        /* \ 
         * 
         */
        glVertex3f( 0.0f,        ARROW_SIZE,  0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f,        0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,        ARROW_SIZE, -ARROW_LENGTH);
        
        /* 
         *  /
         */
        glVertex3f( ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE, -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE,  0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f,        0.0f        );
        
        /* 
         * \
         */
        glVertex3f(-ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE, -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE,  0.0f        );
        glVertex3f(-ARROW_SIZE,  0.0f,        0.0f        );
        
        /* /
         * 
         */
        glVertex3f(-ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,        ARROW_SIZE, -ARROW_LENGTH);
        glVertex3f( 0.0f,        ARROW_SIZE,  0.0f        );
        glVertex3f(-ARROW_SIZE,  0.0f,        0.0f        );
        
        // Front cap
        glVertex3f( 0.0f,        ARROW_SIZE,  0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f      ,  0.0f        );
        glVertex3f( 0.0f,        -ARROW_SIZE, 0.0f        );
        glVertex3f(-ARROW_SIZE,  0.0f,        0.0f        );
        
        // Bottom cap
        // Disabled due uselessness
        //~ glVertex3f( 0.0f,        ARROW_SIZE, -ARROW_LENGTH);
        //~ glVertex3f( ARROW_SIZE,  0.0f      , -ARROW_LENGTH);
        //~ glVertex3f( 0.0f,        -ARROW_SIZE,-ARROW_LENGTH);
        //~ glVertex3f(-ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
         
    glEnd();
    
    // Arrowhead
    /*   /\
     *  /  \
     * /____\
     * 
     */
    glColor3f(0.5f, 0.5f, 0.5f);
    glBegin(GL_TRIANGLES);
        /*   /|
         *  / |
         * /__|
         * (upper)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f( ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,          ARROWHEAD_YS, 0.0f);
        
        /*   /|
         *  / |
         * /__|
         * (lower)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f( ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,         -ARROWHEAD_YS, 0.0f);
        
        /*    |\
         *    | \
         *    |__\
         * (upper)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f(-ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,          ARROWHEAD_YS, 0.0f);
        
        /*    |\
         *    | \
         *    |__\
         * (lower)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f(-ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,         -ARROWHEAD_YS, 0.0f);
        
        // Cap
        glVertex3f( 0.0f,         ARROWHEAD_YS,  0.0f        );
        glVertex3f( ARROWHEAD_XS, 0.0f,          0.0f        );
        glVertex3f( 0.0f,        -ARROWHEAD_YS,  0.0f        );
        glVertex3f(-ARROWHEAD_XS, 0.0f,          0.0f        );
    glEnd();
    
    glPopMatrix();
}

long *collidesSnowman(float x, float z) {
    int snx, snz; // Nearest snowman x and z in snowman matrix

    // Get nearest snowman position 
    snx = round(x / SNOWMAN_MATRIX_DENSITY);
    snz = round(z / SNOWMAN_MATRIX_DENSITY);

    // Check whether given position is too far away
    if ( !(snx > SNOWMAN_MATRIX_SIZE_X || snx < 0 || snz > SNOWMAN_MATRIX_SIZE_Z || snz < 0) ) { 
    
        // If distance to nearest snowman is smaller or equal to SNOWMAN_RADIUS...
        if (sqrt(_square(x - snx * SNOWMAN_MATRIX_DENSITY) + _square(z - snz * SNOWMAN_MATRIX_DENSITY)) <= SNOWMAN_RADIUS) {
            // and the snowman isn't already destroyed...
            if (snowmanMatrix[snz][snx]) {
                return &snowmanMatrix[snz][snx];
            }
        }
    }

    return bin;
}

void bulletStep() {
    // Destruct bullet if it flew too much
    if (bullet.flew >= BULLET_MAX_DIST) bullet.enabled = 0;
    if (!bullet.enabled) return;
    
    *((long *) bin) = 0;
    (*collidesSnowman(bullet.x, bullet.z)) -= GUN_DAMAGE;

    bullet.enabled = *((long *) bin) != 0;

    bullet.x += bullet.lx * BULLET_SPEED * tpf / DynaSBF_degree;
    bullet.z += bullet.lz * BULLET_SPEED * tpf / DynaSBF_degree;
    bullet.flew += BULLET_SPEED * tpf / DynaSBF_degree;
}

void bulletLogic() {
    DynaSBF_degree = tpf * DYNASBF_Q + 1;

    for (S_uint32_t i = 0; i < DynaSBF_degree; i++) {
        bulletStep();
    }
}

void renderScene() {
    frame_begin = gettime();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0.6f, 0.85f, 0.91f, 1.0f);
    
	glLoadIdentity();

    if (helpOpened) {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        
        glDisable(GL_DEPTH_TEST);
        loadTexture();
        glBindTexture(GL_TEXTURE_2D, texture);
        glBegin(GL_QUADS);
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, 0.0f);
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, 0.0f);
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, 0.0f);
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, 0.0f);
        glEnd();
        glBindTexture(GL_TEXTURE_2D, 0);
        glEnable(GL_DEPTH_TEST);

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
    } else {
        computePos(deltaMove);
        computeDir(deltaAngle);

        gunLogic();
        bulletLogic();

        snprintf(&buf[0], BUF_SZ, "%.1f s; x:%.1f; z:%.1f; %.0f FPS", gettime() - t_begin, x, z, 1 / tpf);
        
        glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
        drawString(&buf[0], -1.0f, 0.8f);


#ifdef DEBUG_FEATURES
            gluLookAt(	x,                     EYE_Y + 10 * upperView,   z,
                        x + lx * !upperView,   EYE_Y,                    z + lz * !upperView,
                        0.0f, 1 - upperView,   upperView	);
#else
            gluLookAt(	x,      EYE_Y,  z,
                        x+lx,   EYE_Y,  z+lz,
                        0.0f,   1.0f,   0.0f	);
#endif
        
        glColor3f(0.9f, 0.9f, 0.9f);
        
        glBegin(GL_QUADS);
            glVertex3f(-100.0f, 0.0f, -100.0f);
            glVertex3f(-100.0f, 0.0f,  100.0f);
            glVertex3f( 100.0f, 0.0f,  100.0f);
            glVertex3f( 100.0f, 0.0f, -100.0f);
        glEnd();
        
        register int currentHP;

        for (unsigned int z = 0; z < SNOWMAN_MATRIX_SIZE_Z; z++)
            for (unsigned int x = 0; x < SNOWMAN_MATRIX_SIZE_X; x++)
            {
                currentHP = snowmanMatrix[z][x];

                if (currentHP <= 0) continue;
                glPushMatrix();
                
                glTranslatef(x * SNOWMAN_MATRIX_DENSITY, 0, z * SNOWMAN_MATRIX_DENSITY);
                
                // Hitboxes
                //~ glColor3f(0.5f, 1.0f, 0.5f);
                //~ glBegin(GL_QUADS);
                    //~ glVertex3f(-0.5f, 2.0f, -0.5f);
                    //~ glVertex3f(-0.5f, 2.0f,  0.5f);
                    //~ glVertex3f( 0.5f, 2.0f,  0.5f);
                    //~ glVertex3f( 0.5f, 2.0f, -0.5f);
                //~ glEnd();
            
                drawSnowMan(currentHP);
			
                glPopMatrix();
            }
    
        drawBullet();
        drawGun();
    }
        
	glutSwapBuffers();

    tpf = gettime() - frame_begin;
}
 
 
void pressKey(int key, int xx, int yy) {
 
	switch (key) {

        case GLUT_KEY_F1:
            helpOpened = !helpOpened;
            break;
	}
}
 
void releaseKey(int key, int x, int y) {}

void pressNormalKey(unsigned char key, int x, int y) {
    switch (key) {
        case 'a':
            deltaAngle = -RSPEED * tpf;
            break;
        case 'd':
            deltaAngle = RSPEED * tpf;
            break;
        case 'w':
            deltaMove = SPEED * tpf;
            break;
        case 's':
            deltaMove = -SPEED * tpf;
            break;
        case ' ':
            shoot();
            break;
#ifdef DEBUG_FEATURES
        case 'u':
            upperView = !upperView;
            break;
#endif
        case 27:
            exit(1);
            break;
    }
}

void releaseNormalKey(unsigned char key, int xx, int yy) {
    switch (key) {
        case 'a':
        case 'd': 
            deltaAngle = 0.0f;
            break;
        case 'w':
        case 's': 
            deltaMove = 0;
            break;
        case 'h':
            fixPosition();
            break;
    }
}

void shoot() {
    
    if (gunReload == 0.0f && bullet.enabled == 0) {
        bullet.x = x;
        bullet.z = z;
        bullet.lx = lx;
        bullet.lz = lz;
        bullet.angle = angle; // needed for arrow drawing
        bullet.enabled = 1;
        bullet.flew = 0;
        
        gunReload = GUNRELOAD_MAX;
    }
}

void drawString(const unsigned char *s, float x, float y) {
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    glDisable(GL_DEPTH_TEST);

    glRasterPos2f(x, y);
    for (const unsigned char *c = s; *c != '\0'; c++) {
        glutBitmapCharacter(FONT, *c);
    }

    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
}

void resetSnowmanMatrix() {
    for (unsigned int z = 0; z < SNOWMAN_MATRIX_SIZE_Z; z++) {
        for (unsigned int x = 0; x < SNOWMAN_MATRIX_SIZE_X; x++) {
            snowmanMatrix[z][x] = SNOWMAN_MAX_HP;
        }
    }
}
void resetBullet() {
    bullet.x = 0;
    bullet.z = 0;
    bullet.lx = 0;
    bullet.lz = 0;
    bullet.enabled = 0;
    bullet.flew = 0;
    bullet.angle = 0;
}
 
void fixPosition() {    // Requires resetSnowmanMatrix
    while(collidesSnowman(x, z) != bin) {
        x -= 0.1f;
        z -= 0.1f;
    }
}

int main(int argc, char **argv) {
    bin = malloc(8);

    resetBullet();
    resetSnowmanMatrix();
    fixPosition();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(400,400);
	glutCreateWindow("Snowman shooter");

	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);
	glutSpecialFunc(pressKey);
    glutKeyboardFunc(pressNormalKey);
    
    glutSetCursor(GLUT_CURSOR_NONE);
    
	glutIgnoreKeyRepeat(1);
	glutSpecialUpFunc(releaseKey);
    glutKeyboardUpFunc(releaseNormalKey);

    t_begin = gettime();

	glEnable(GL_DEPTH_TEST);
 	glEnable(GL_TEXTURE_2D);
        
	glutMainLoop();
 
	return 1;
}
