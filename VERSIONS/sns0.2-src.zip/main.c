#ifdef _WIN32
#   include <windows.h>
#   define GLUT_DISABLE_ATEXIT_HACK
#else
#   include <stdlib.h>
#   include <time.h>
#   include <sys/time.h>
#   include <inttypes.h>
#endif

// Idk if _USE_MATH_DEFINES does something on Linux or Mac
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>
#include <string.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

// #include "Instructions_image.h"


// Movement
#define SPEED 180.0f
#define RSPEED 3.0f
#define EYE_Y 1.0f

// Gun
#define GUN_ROT M_PI_4 / 3
#define GUNRELOAD_MAX 0.1f
#define GUNRELOAD_TIME 0.16f
#define GUN_DAMAGE 1

// Bullet
#define BULLET_Y EYE_Y - 0.3f
#define BULLET_SPEED 60.0f
#define BULLET_MAX_DIST 20.0f
#define DYNASBF_Q 50                 // DynaSBF = Dynamic SBF; SBF = Smooth Bullet Flight

// Gas
#define GAS_SPEED 5.0f
#define GAS_MAX_DIST INFINITY
#define GAS_CLOUDS 5
#define GAS_RADIUS 1.0f

// Snowman
#define SNOWMAN_MATRIX_SIZE_X 10
#define SNOWMAN_MATRIX_SIZE_Z 10
#define SNOWMAN_MATRIX_DENSITY 5
#define SNOWMAN_RADIUS 1.0f
#define SNOWMAN_MAX_HP 3

// Snowman model
#define SNOWMAN_HEAD_MIN_HEIGHT 0.75f

// Arrow model
#define ARROW_SIZE 0.02f
#define ARROW_LENGTH 1.5f
#define ARROWHEAD_Z 0.2f
#define ARROWHEAD_XS 0.1f
#define ARROWHEAD_YS 0.03f

// Bow model
#define BOW_THICKNESS 0.03f
#define BOWBODY_FRONT_LN 0.3f
#define BOWBODY_CURVE_OFFSET 0.2f
#define BOWBODY_CURVE_LN 0.7f
#define BOW_HOLE_THICKNESS 0.025f
#define BOWSPRING_MAX_TENSION 0.2f

// Gas model
#define GAS_Y 1.5f

// Misc
#define FONT GLUT_BITMAP_8_BY_13
#define BUF_SZ 256
#define T_EXIT_AFTER_WIN 10
#define VERSION "0.2"

// Ending types
#define NO_END 0
#define END_WIN 1
#define END_LOSE 2

// Config
// #define DEBUG_FEATURES
// #define STAB_IFS
#define GL_ERRORS_ARE_FATAL
#define RENDER_DISTANCE       // Notice: if RENDER_DISTANCE is on, GPU will work less, but processor will work more!

#ifdef _WIN32
typedef DWORD S_uint32_t;
#else
typedef uint32_t S_uint32_t;
#endif

#if defined(__GCC__)
#define PACK __attribute__((__packed__))
#elif defined(__clang__)
#define PACK __attribute__((packed))
#else
#define PACK
#endif

typedef struct PACK _ {
    float x, z, lx, lz, flew, angle, maxDist, speed;
    _Bool enabled;
} bullet_t;

float angle = 0.0;
float lx = 0.0f, lz = -1.0f;
float x = SNOWMAN_MATRIX_SIZE_X * SNOWMAN_MATRIX_DENSITY / 2, z = SNOWMAN_MATRIX_SIZE_Z * SNOWMAN_MATRIX_DENSITY / 2;
float deltaAngle = 0.0f;
float deltaMove = 0;
float gunReload = 0.0f;
bullet_t bullet;
long snowmanMatrix[SNOWMAN_MATRIX_SIZE_Z][SNOWMAN_MATRIX_SIZE_X];
_Bool helpOpened = 1;
// _Bool textureLoaded = 0;
// GLuint texture;
double t_begin = 0, t_end = 0, frame_begin = 0, tpf = 0.16f;
unsigned char buf[BUF_SZ];
int width, height;
S_uint32_t DynaSBF_degree = 1;
void *bin;                      // IF killer
S_uint32_t stableFPS = 0;
S_uint32_t stableFPSCounter = 0;
double lastStableFPSUpdate = 0;
S_uint32_t end = 0;
S_uint32_t quality = 1;
S_uint32_t snowmenLeft = SNOWMAN_MATRIX_SIZE_X * SNOWMAN_MATRIX_SIZE_Z;
float renderDistance = 50.0f;
bullet_t gasPhys[GAS_CLOUDS];

#ifdef DEBUG_FEATURES
_Bool upperView = 0;
#endif

void shoot();
void resetSnowmanMatrix();
void resetBullet();
void drawString(const unsigned char *, float, float);
void loadTexture();
double gettime();
float squaref(float);
void changeSize(int, int);
void computePos(float);
void computeDir(float);
void drawGun();
void gunLogic();
void drawBullet();
void bulletStep(bullet_t *);
void bulletLogic(bullet_t *);
void renderScene();
void pressKey(int, int, int);
void releaseKey(int, int, int);
void pressNormalKey(unsigned char, int, int);
void releaseNormalKey(unsigned char, int, int);
long *collidesSnowman(float, float);
void fixPosition();
float getDistance2Df(float, float, float, float);
void resetGasPhys();
void allGasTarget(float, float);
void oneGasTarget(float, float, bullet_t *);
void drawOneGas();
void gasLogic();
void gasPostLogic();
void drawAllGas();
const unsigned char *getEndText(S_uint32_t);

// #define functions
#define checkError() checkError_(__FILE__, __LINE__) 
#define RADTODEG(x) ((x) * 57.29577951308232)

// Inline functions

// Optimization. pow(n, 2) from <math.h> might be slower
inline float squaref(float n) {
    return n * n;
}

// Utility
inline _Bool canRender(float xx, float zz) {
    return getDistance2Df(xx, zz, x, z) < renderDistance;
}

// Normal functions
#ifdef _WIN32
double gettime() {
    FILETIME ft;
    
    GetSystemTimeAsFileTime(&ft);
    
    return (double)((ft.dwHighDateTime & 0x7f) << 25 | ft.dwLowDateTime >> 7) / 78125;
}
#else
double gettime() {
    struct timeval t;

    gettimeofday(&t, 0);
    return ((double)t.tv_usec)/ 1000000 + t.tv_sec;
}
#endif
// void loadTexture() {
//     if (!textureLoaded) {
//         glGenTextures(1, &texture);
//         glBindTexture(GL_TEXTURE_2D, texture);
        
//         glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Instructions_width, Instructions_height, 0, GL_RGB, GL_UNSIGNED_BYTE, Instructions);
//         glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//         glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        
//         glBindTexture(GL_TEXTURE_2D, 0);
        
//         textureLoaded = 1;
//         printf("Loaded instructions\n");
//     }
// }

void checkError_(const char *file, int line)
{
    GLenum errorCode;
    S_uint32_t errorsOccurred = 0;
    while ((errorCode = glGetError()) != GL_NO_ERROR)
    {

        switch (errorCode)
        {
            case GL_INVALID_ENUM:                  strcpy(buf, "GL_INVALID_ENUM"); break;
            case GL_INVALID_VALUE:                 strcpy(buf, "GL_INVALID_VALUE"); break;
            case GL_INVALID_OPERATION:             strcpy(buf, "GL_INVALID_OPERATION"); break;
            case GL_STACK_OVERFLOW:                strcpy(buf, "GL_STACK_OVERFLOW"); break;
            case GL_STACK_UNDERFLOW:               strcpy(buf, "GL_STACK_UNDERFLOW"); break;
            case GL_OUT_OF_MEMORY:                 strcpy(buf, "GL_OUT_OF_MEMORY"); break;
            case GL_INVALID_FRAMEBUFFER_OPERATION: strcpy(buf, "GL_INVALID_FRAMEBUFFER_OPERATION"); break;
        }
        errorsOccurred++;
        fprintf(stderr, "OpenGL error %s occurred at file %s at line %d\n", buf, file, line);
    }

#ifdef GL_ERRORS_ARE_FATAL
    if (errorsOccurred) {
        fprintf(stderr, "%d error(s) occurred. Exiting.\n", errorsOccurred);
    }
#endif
}

// Utility
float getDistance2Df(float x1, float y1, float x2, float y2) {
    return sqrt(squaref(x1 - x2) + squaref(y1 - y2));
}

void changeSize(int w, int h) {
	if (h == 0)
		h = 1;
	float ratio =  w * 1.0f / h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glViewport(0, 0, w, h);

	gluPerspective(45.0f, ratio, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);

    width = w;
    height = h;
}

void drawSnowMan(long health) {
#ifdef STAB_IFS
    if (health <= 0) return;
#endif

 	glColor3f(1.0f, 1.0f, 1.0f);
 	
    // Snowman's body
	glTranslatef(0.0f, 0.75f, 0.0f);
	glutSolidSphere(0.75f, (quality + 1) * 10, (quality + 1) * 10);
 	
    // Snowman's head
	glTranslatef(0.0f, 1.0f * ( ((float) health - 1) / (SNOWMAN_MAX_HP - 1) * (1 - SNOWMAN_HEAD_MIN_HEIGHT) + SNOWMAN_HEAD_MIN_HEIGHT), 0.0f);
	glutSolidSphere(0.25f, (quality + 1) * 7, (quality + 1) * 7);
	
    // Snowman's eyes
	glPushMatrix();
	glColor3f(0.0f, 0.0f, 0.0f);
	glTranslatef(0.05f, 0.10f, 0.18f);
	glutSolidSphere(0.05f, (quality + 1) * 4, (quality + 1) * 4);
	glTranslatef(-0.1f, 0.0f, 0.0f);
	glutSolidSphere(0.05f, (quality + 1) * 4, (quality + 1) * 4);
	glPopMatrix();
    
	// Snowman's nose
	glColor3f(1.0f, 0.5f , 0.5f);
	glutSolidCone(0.08f, 0.5f, quality * 5, 2);
}

void computePos(float deltaMove) {
    register float x1 = x + deltaMove * lx * 0.1f, z1 = z + deltaMove * lz * 0.1f;
	
    if (collidesSnowman(x1, z1) == bin) {
        x = x1; z = z1;
    }
}
 
void computeDir(float deltaAngle) {
	angle += deltaAngle;
	lx = sin(angle);
	lz = -cos(angle);
}

void drawGun() {
    glPushMatrix();
    
    computeDir(GUN_ROT);
    glTranslatef(x + lx, EYE_Y - 0.3f, z + lz);
    computeDir(-GUN_ROT);
    glRotatef(180.0f - RADTODEG(angle), 0.0f, 1.0f, 0.0f);
    glRotatef(85.0f, 0.0f, 0.0f, -1.0f);

   
    //~ glutSolidCone(0.15f, 0.5f, 30, 2);
    
    /*        ________
     *  _____/ __o___ \______ 
     * |______/------\_______|
     */
    
    /*        
     *  
     *         ------
     */


    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET                                                      );
        glVertex3f( 0.0f            ,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET - BOWSPRING_MAX_TENSION * (gunReload / GUNRELOAD_MAX));
        glVertex3f( 0.0f            ,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET - BOWSPRING_MAX_TENSION * (gunReload / GUNRELOAD_MAX));
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET                                                      );
    glEnd();

    glColor3f(0.58f, 0.32f, 0.0f);

    // Very hard...
    glBegin(GL_QUADS);
        
        // -----------------------
        //        UPPER PART
        // -----------------------        
    
        /*        ________
         *        ________ 
         * (upper)
         */
    
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        
        /*
         *               ________ 
         *               \_______|
         * (upper)
         */
    
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       );
        
        /*  
         *  _______ 
         * |______/
         * (upper)
         */
        
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       );
        
        // -----------------------
        //        LOWER PART
        // -----------------------  
        
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       );
        
        /*        ________
         *        ________ 
         * (lower)
         */
    
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        
        /*
         *               ________ 
         *               \_______|
         * (lower)
         */
    
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f( BOWBODY_CURVE_LN, -BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       );
        
        /*  
         *  _______ 
         * |______/
         * (lower)
         */
         
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS,  BOW_THICKNESS                       );
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS,  BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       );
        
        // -----------------------
        //        "WALLS"
        // -----------------------
        
        /*        
         *         ______
         * 
         */
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS);
        
        /*  
         *  
         *  ______
         */
        
        glVertex3f(-BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       ); 
        glVertex3f(-BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f(-BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       ); 
        
        /*
         *
         *                _______
         */
         
        glVertex3f( BOWBODY_FRONT_LN,  BOW_THICKNESS, -BOW_THICKNESS                       ); 
        glVertex3f( BOWBODY_CURVE_LN,  BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_CURVE_LN, -BOW_THICKNESS, -BOW_THICKNESS - BOWBODY_CURVE_OFFSET);
        glVertex3f( BOWBODY_FRONT_LN, -BOW_THICKNESS, -BOW_THICKNESS                       ); 
    glEnd();
    
    glPopMatrix();
}

void gunLogic() {
    if (gunReload > 0.0f) {
        gunReload -= GUNRELOAD_MAX / GUNRELOAD_TIME * tpf;
        
        if (gunReload < 0.0f) gunReload = 0.0f; // oops, we did too much :o)
    }
}

void drawBullet() {
    if (!bullet.enabled) return;
    
    glPushMatrix();
    
    glTranslatef(bullet.x, BULLET_Y, bullet.z);
    glRotatef(180 - RADTODEG(bullet.angle), 0.0f, 1.0f, 0.0f);
        
    glColor3f(0.45f, 0.29f, 0.19f);
    
    // Arrow body
    
    /* /\
     * \/
     */
    glBegin(GL_QUADS);
        /* \ 
         * 
         */
        glVertex3f( 0.0f,        ARROW_SIZE,  0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f,        0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,        ARROW_SIZE, -ARROW_LENGTH);
        
        /* 
         *  /
         */
        glVertex3f( ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE, -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE,  0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f,        0.0f        );
        
        /* 
         * \
         */
        glVertex3f(-ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE, -ARROW_LENGTH);
        glVertex3f( 0.0f,       -ARROW_SIZE,  0.0f        );
        glVertex3f(-ARROW_SIZE,  0.0f,        0.0f        );
        
        /* /
         * 
         */
        glVertex3f(-ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
        glVertex3f( 0.0f,        ARROW_SIZE, -ARROW_LENGTH);
        glVertex3f( 0.0f,        ARROW_SIZE,  0.0f        );
        glVertex3f(-ARROW_SIZE,  0.0f,        0.0f        );
        
        // Front cap
        glVertex3f( 0.0f,        ARROW_SIZE,  0.0f        );
        glVertex3f( ARROW_SIZE,  0.0f      ,  0.0f        );
        glVertex3f( 0.0f,        -ARROW_SIZE, 0.0f        );
        glVertex3f(-ARROW_SIZE,  0.0f,        0.0f        );
        
        // Bottom cap
        // Disabled due uselessness
        //~ glVertex3f( 0.0f,        ARROW_SIZE, -ARROW_LENGTH);
        //~ glVertex3f( ARROW_SIZE,  0.0f      , -ARROW_LENGTH);
        //~ glVertex3f( 0.0f,        -ARROW_SIZE,-ARROW_LENGTH);
        //~ glVertex3f(-ARROW_SIZE,  0.0f,       -ARROW_LENGTH);
         
    glEnd();
    
    // Arrowhead
    /*   /\
     *  /  \
     * /____\
     * 
     */
    glColor3f(0.5f, 0.5f, 0.5f);
    glBegin(GL_TRIANGLES);
        /*   /|
         *  / |
         * /__|
         * (upper)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f( ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,          ARROWHEAD_YS, 0.0f);
        
        /*   /|
         *  / |
         * /__|
         * (lower)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f( ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,         -ARROWHEAD_YS, 0.0f);
        
        /*    |\
         *    | \
         *    |__\
         * (upper)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f(-ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,          ARROWHEAD_YS, 0.0f);
        
        /*    |\
         *    | \
         *    |__\
         * (lower)
         */
        glVertex3f( 0.0f,          0.0f,         ARROWHEAD_Z);
        glVertex3f(-ARROWHEAD_XS,  0.0f,         0.0f);
        glVertex3f( 0.0f,         -ARROWHEAD_YS, 0.0f);
        
        // Cap
        glVertex3f( 0.0f,         ARROWHEAD_YS,  0.0f        );
        glVertex3f( ARROWHEAD_XS, 0.0f,          0.0f        );
        glVertex3f( 0.0f,        -ARROWHEAD_YS,  0.0f        );
        glVertex3f(-ARROWHEAD_XS, 0.0f,          0.0f        );
    glEnd();
    
    glPopMatrix();
}

long *collidesSnowman(float x, float z) {
    int snx, snz; // Nearest snowman x and z in snowman matrix

    // Get nearest snowman position 
    snx = round(x / SNOWMAN_MATRIX_DENSITY);
    snz = round(z / SNOWMAN_MATRIX_DENSITY);

    // Check whether given position is too far away
    if ( !(snx > SNOWMAN_MATRIX_SIZE_X || snx < 0 || snz > SNOWMAN_MATRIX_SIZE_Z || snz < 0) ) { 

        // If distance to nearest snowman is smaller or equal to SNOWMAN_RADIUS...
        if (getDistance2Df(x, z, snx * SNOWMAN_MATRIX_DENSITY, snz * SNOWMAN_MATRIX_DENSITY) <= SNOWMAN_RADIUS) {
            // and the snowman isn't already destroyed, (x, z) collides snowman.
            if (snowmanMatrix[snz][snx] > 0) {
                return &snowmanMatrix[snz][snx];
            }
        }
    }

    return bin;
}

void bulletStep(bullet_t *b) {
    // Destruct bullet if it flew too much
    if (b->flew >= b->maxDist) b->enabled = 0;
    if (!b->enabled) return;
    
    *((long *) bin) = 0;
    (*collidesSnowman(b->x, b->z)) -= GUN_DAMAGE;

    b->enabled = *((long *) bin) != 0;

    b->x += b->lx * b->speed * tpf / DynaSBF_degree;
    b->z += b->lz * b->speed * tpf / DynaSBF_degree;
    b->flew += b->speed * tpf / DynaSBF_degree;
}

void bulletLogic(bullet_t *b) {
    DynaSBF_degree = tpf * DYNASBF_Q + 1;

    for (S_uint32_t i = 0; i < DynaSBF_degree; i++) {
        bulletStep(b);
    }
}

void drawOneGas() {
    // glColor4f(0.5f, 1.0f, 0.0f, 0.5f);
    glColor4f(0.75f, 0.85f, 0.25f, 0.5f);

    glutSolidSphere(GAS_RADIUS, 10, 10);
}

void drawAllGas() {
    for (S_uint32_t i = 0; i < GAS_CLOUDS; i++) {
        if (canRender(gasPhys[i].x, gasPhys[i].z)) {
            glPushMatrix();

            glTranslatef(gasPhys[i].x, GAS_Y, gasPhys[i].z);
            drawOneGas();

            glPopMatrix();
        }
    }
}

void gasLogic() {
    float averageGas0Distance = 0;
    for (S_uint32_t i = 0; i < GAS_CLOUDS; i++) {
        allGasTarget(x, z);
        bulletLogic(&gasPhys[i]);
        gasPhys[i].enabled = 1;
        averageGas0Distance += getDistance2Df(gasPhys[0].x, gasPhys[0].z, gasPhys[i].x, gasPhys[i].z);
    }
    averageGas0Distance /= GAS_CLOUDS - 1;
    if (averageGas0Distance < GAS_RADIUS * 5) {
        resetGasPhys();
    }
}

void gasPostLogic() {
    for (S_uint32_t i = 0; i < GAS_CLOUDS; i++) {
        if (getDistance2Df(x, z, gasPhys[i].x, gasPhys[i].z) <= GAS_RADIUS) {
            end = END_LOSE;
        }
    }
}

void renderScene() {
    frame_begin = gettime();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0.6f, 0.85f, 0.91f, 1.0f);
    
	glLoadIdentity();

    if (helpOpened) {
        // glMatrixMode(GL_PROJECTION);
        // glPushMatrix();
        // glLoadIdentity();
        // glMatrixMode(GL_MODELVIEW);
        
        // glDisable(GL_DEPTH_TEST);
        // loadTexture();
        // glBindTexture(GL_TEXTURE_2D, texture);
        // glBegin(GL_QUADS);
        //     glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, 0.0f);
        //     glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, 0.0f);
        //     glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, 0.0f);
        //     glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, 0.0f);
        // glEnd();
        // glBindTexture(GL_TEXTURE_2D, 0);
        // glEnable(GL_DEPTH_TEST);

        // glMatrixMode(GL_PROJECTION);
        // glPopMatrix();
        // glMatrixMode(GL_MODELVIEW);
        glColor3f(0.0f, 0.0f, 0.0f);
        snprintf(&buf[0], BUF_SZ, "Use W/S keys to walk,");
        drawString(&buf[0], -1.0f,  0.9f);
        snprintf(&buf[0], BUF_SZ, "A/D to look around.");
        drawString(&buf[0], -1.0f,  0.8f);
        snprintf(&buf[0], BUF_SZ, "Space to shoot.");
        drawString(&buf[0], -1.0f,  0.7f);
        snprintf(&buf[0], BUF_SZ, "Press H if you're stuck");
        drawString(&buf[0], -1.0f,  0.6f);
        snprintf(&buf[0], BUF_SZ, "in a snowman.");
        drawString(&buf[0], -1.0f,  0.5f);
        snprintf(&buf[0], BUF_SZ, "Use [ and ] keys to");
        drawString(&buf[0], -1.0f,  0.4f);
        snprintf(&buf[0], BUF_SZ, "reduce and increase");
        drawString(&buf[0], -1.0f,  0.3f);
        snprintf(&buf[0], BUF_SZ, "quality, respectively.");
        drawString(&buf[0], -1.0f,  0.2f);
        snprintf(&buf[0], BUF_SZ, "Use - and = keys to");
        drawString(&buf[0], -1.0f,  0.1f);
        snprintf(&buf[0], BUF_SZ, "reduce and increase");
        drawString(&buf[0], -1.0f,  0.0f);
        snprintf(&buf[0], BUF_SZ, "render distance, respectively.");
        drawString(&buf[0], -1.0f, -0.1f);
        snprintf(&buf[0], BUF_SZ, "Aware of green gas! It will");
        drawString(&buf[0], -1.0f, -0.2f);
        snprintf(&buf[0], BUF_SZ, "kill you immediately.");
        drawString(&buf[0], -1.0f, -0.3f);
        snprintf(&buf[0], BUF_SZ, "Green gas also destroys snowmen.");
        drawString(&buf[0], -1.0f, -0.4f);
        snprintf(&buf[0], BUF_SZ, "Press F1 to dimiss this help.");
        drawString(&buf[0], -1.0f, -0.5f);
        snprintf(&buf[0], BUF_SZ, "When game starts, try to run away.");
        drawString(&buf[0], -1.0f, -0.7f);
        snprintf(&buf[0], BUF_SZ, "Your target - destroy all snowmen.");
        drawString(&buf[0], -1.0f, -0.8f);


    } else {

        computePos(deltaMove * !end * tpf);
        computeDir(deltaAngle * !end * tpf);

        gunLogic();
        bulletLogic(&bullet);
        if (!end) {
            gasLogic();
        }
        

        glColor4f(0.0f, 0.0f, 0.0f, 1.0f);

        snprintf(&buf[0], BUF_SZ, "%.1f s; x:%.1f; z:%.1f; %d FPS; %dx%d", gettime() * !end + t_end * !!end - t_begin, x, z, stableFPS, height, width);
        drawString(&buf[0], -1.0f, 0.9f);

        snprintf(&buf[0], BUF_SZ, "DynaSBF:%d; quality:%d; render distance:%.f", DynaSBF_degree, quality, renderDistance);
        drawString(&buf[0], -1.0f, 0.8f);

        snprintf(&buf[0], BUF_SZ, "snowmen left:%d gas0 x:%.1f gas0 z:%.1f", snowmenLeft, gasPhys[0].x, gasPhys[0].z);
        drawString(&buf[0], -1.0f, 0.7f);

        drawString(getEndText(end), 0.0f, 0.0f);

        snprintf(&buf[0], BUF_SZ, "Press ESC to exit . . .");
        buf[0] *= !!end;
        drawString(&buf[0], 0.0f, 0.2f);


#ifdef DEBUG_FEATURES
            gluLookAt(	x,                     EYE_Y + 10 * upperView,   z,
                        x + lx * !upperView,   EYE_Y,                    z + lz * !upperView,
                        0.0f, 1 - upperView,   upperView	);
#else
            // gluLookAt(	x,      EYE_Y,  z,
                        // x+lx,   EYE_Y,  z+lz,
                        // 0.0f,   1.0f,   0.0f	);
            glRotatef(RADTODEG(angle), 0.0f, 1.0f, 0.0f);
            glTranslatef(-x, -EYE_Y, -z);
#endif

        glColor3f(0.9f, 0.9f, 0.9f);
        
        glBegin(GL_QUADS);
            glVertex3f(-10000.0f, 0.0f, -10000.0f);
            glVertex3f(-10000.0f, 0.0f,  10000.0f);
            glVertex3f( 10000.0f, 0.0f,  10000.0f);
            glVertex3f( 10000.0f, 0.0f, -10000.0f);
        glEnd();

        if (end) {

            if (t_end + T_EXIT_AFTER_WIN < gettime()) exit(0);

        } else {
            drawAllGas();

            register int currentHP;
            snowmenLeft = 0;

            for (unsigned int z = 0; z < SNOWMAN_MATRIX_SIZE_Z; z++)
                for (unsigned int x = 0; x < SNOWMAN_MATRIX_SIZE_X; x++){
                    currentHP = snowmanMatrix[z][x];

                    if (currentHP <= 0) continue;
                    snowmenLeft++;
#ifdef RENDER_DISTANCE
                    if (canRender(x * SNOWMAN_MATRIX_DENSITY, z * SNOWMAN_MATRIX_DENSITY)) {
#endif
                        glPushMatrix();
                
                        glTranslatef(x * SNOWMAN_MATRIX_DENSITY, 0, z * SNOWMAN_MATRIX_DENSITY);
                
                        // Hitboxes
                        // ~ glColor3f(0.5f, 1.0f, 0.5f);
                        //~ glBegin(GL_QUADS);
                            // ~ glVertex3f(-0.5f, 2.0f, -0.5f);
                            //~ glVertex3f(-0.5f, 2.0f,  0.5f);
                            //~ glVertex3f( 0.5f, 2.0f,  0.5f);
                            //~ glVertex3f( 0.5f, 2.0f, -0.5f);
                        //~ glEnd();
            
                        drawSnowMan(currentHP);
            
                        glPopMatrix();
#ifdef RENDER_DISTANCE
                    }
#endif
            }

            drawBullet();
            drawGun();

            gasPostLogic();

            if (end == NO_END) end = !snowmenLeft * END_WIN;

            if (end) {
                t_end = gettime();
            }
        }
    }

    checkError();
	glutSwapBuffers();

    // Debug
    // printf("\nx=%.1f z=%.1f\n", x, z);
    // for (S_uint32_t xx = 0; xx < SNOWMAN_MATRIX_SIZE_X; xx++) {
    //     for (S_uint32_t zz = 0; zz < SNOWMAN_MATRIX_SIZE_Z; zz++) {
    //         if (collidesSnowman(x, z) != bin) printf("[%ld] ", snowmanMatrix[zz][xx]);
    //         else printf(" %ld  ", snowmanMatrix[zz][xx]);
    //     }
    //     printf ("\n");
    // }

    tpf = gettime() - frame_begin;
    stableFPSCounter++;
    lastStableFPSUpdate += tpf;
    if (lastStableFPSUpdate >= 1.0) {
        lastStableFPSUpdate = 0.0;
        stableFPS = stableFPSCounter;
        stableFPSCounter = 0;
    }

}

const unsigned char *getEndText(S_uint32_t endType) {
    switch (endType) {
        case NO_END:
            strcpy(buf, "");
            break;
        case END_WIN:
            strcpy(buf, "You win!");
            break;
        case END_LOSE:
            strcpy(buf, "You lose!");
            break;
    }

    return &buf[0];
}

void pressKey(int key, int xx, int yy) {
 
	switch (key) {

        case GLUT_KEY_F1:
            helpOpened = !helpOpened;
            break;
	}
}
 
void releaseKey(int key, int x, int y) {}

void pressNormalKey(unsigned char key, int x, int y) {
    switch (key) {
        case 'a':
            deltaAngle = -RSPEED;
            break;
        case 'd':
            deltaAngle = RSPEED;
            break;
        case 'w':
            deltaMove = SPEED;
            break;
        case 's':
            deltaMove = -SPEED;
            break;
        case ' ':
            shoot();
            break;
#ifdef DEBUG_FEATURES
        case 'u':
            upperView = !upperView;
            break;
#endif
        case ']':
            quality++;
            break;
        case '[':
            if (quality > 1) quality--;
            break;
        case '-':
            renderDistance -= 10.0f;
            if (renderDistance < 20.0f) renderDistance = 20.0f;
            break;
        case '=':
            renderDistance += 10.0f;
            break;
        case 27:
            exit(0);
            break;
    }
}

void releaseNormalKey(unsigned char key, int xx, int yy) {
    switch (key) {
        case 'a':
        case 'd': 
            deltaAngle = 0.0f;
            break;
        case 'w':
        case 's': 
            deltaMove = 0;
            break;
        case 'h':
            fixPosition();
            break;
    }
}

void passiveMotionFunc(int x, int y) {
    deltaAngle = (float)(width / 2 - x) / width * RSPEED;
    glutWarpPointer(width / 2, height / 2);
    printf("%f\n", deltaAngle);
    glutPostRedisplay();
}

void shoot() {
    
    if (gunReload == 0.0f && bullet.enabled == 0) {
        bullet.x = x;
        bullet.z = z;
        bullet.lx = lx;
        bullet.lz = lz;
        bullet.angle = angle; // needed for arrow drawing
        bullet.enabled = 1;
        bullet.flew = 0;
        
        gunReload = GUNRELOAD_MAX;
    }
}

void drawString(const unsigned char *s, float x, float y) {
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    glDisable(GL_DEPTH_TEST);

    glRasterPos2f(x, y);
    for (const unsigned char *c = s; *c != '\0'; c++) {
        glutBitmapCharacter(FONT, *c);
    }

    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
}

void resetSnowmanMatrix() {
    for (unsigned int z = 0; z < SNOWMAN_MATRIX_SIZE_Z; z++) {
        for (unsigned int x = 0; x < SNOWMAN_MATRIX_SIZE_X; x++) {
            snowmanMatrix[z][x] = RAND_MAX / 2 < rand() ? SNOWMAN_MAX_HP : 0;
        }
    }
}
void resetBullet() {
    bullet.x = 0;
    bullet.z = 0;
    bullet.lx = 0;
    bullet.lz = 0;
    bullet.enabled = 0;
    bullet.flew = 0;
    bullet.angle = 0;

    bullet.speed = BULLET_SPEED;
    bullet.maxDist = BULLET_MAX_DIST;
}
 
void resetGasPhys() {
    for (S_uint32_t i = 0; i < GAS_CLOUDS; i++) {
        do {
            gasPhys[i].x = rand() % (SNOWMAN_MATRIX_SIZE_X * SNOWMAN_MATRIX_DENSITY);
            gasPhys[i].z = rand() % (SNOWMAN_MATRIX_SIZE_Z * SNOWMAN_MATRIX_DENSITY);
        } while (getDistance2Df(x, z, gasPhys[i].x, gasPhys[i].z) < 20.0f);
        gasPhys[i].lx = 0;
        gasPhys[i].lz = 0;
        gasPhys[i].enabled = 1;
        gasPhys[i].flew = -INFINITY;
        gasPhys[i].angle = NAN;

        gasPhys[i].speed = GAS_SPEED;
        gasPhys[i].maxDist = GAS_MAX_DIST;
    }
}

void allGasTarget(float targetX, float targetZ) {
    for (S_uint32_t i = 0; i < GAS_CLOUDS; i++) {
        oneGasTarget(targetX, targetZ, &gasPhys[i]);
    }
}

void oneGasTarget(float targetX, float targetZ, bullet_t *gas) {
    float d = getDistance2Df(gas->x, gas->z, targetX, targetZ);
    gas->lx = (targetX - gas->x) / d;
    gas->lz = (targetZ - gas->z) / d;
}

void fixPosition() {    // Requires resetSnowmanMatrix
    while(collidesSnowman(x, z) != bin) {
        x -= 0.1f;
        z -= 0.1f;
    }
}

int main(int argc, char **argv) {

    bin = malloc(8);

    srand(time(NULL));
    resetBullet();
    resetSnowmanMatrix();
    resetGasPhys();
    fixPosition();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(400,400);
	glutCreateWindow("Snowman shooter "VERSION);

	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);
	glutSpecialFunc(pressKey);
    glutKeyboardFunc(pressNormalKey);
    
    glutSetCursor(GLUT_CURSOR_NONE);
    
	glutIgnoreKeyRepeat(1);
	glutSpecialUpFunc(releaseKey);
    glutKeyboardUpFunc(releaseNormalKey);

    t_begin = gettime();

	glEnable(GL_DEPTH_TEST);
 	// glEnable(GL_TEXTURE_2D);
        
	glutMainLoop();
 
	return 1;
}
