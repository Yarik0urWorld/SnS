#ifndef _BULLET_T_H
#define _BULLET_T_H

#include "vars.h"

// Bullet type
void bulletStep(bullet_t *);
void bulletLogic(bullet_t *);

#endif
