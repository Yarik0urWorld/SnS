#ifndef _GUN_H
#define _GUN_H

// Gun logic
void gunLogic();

// Gun drawing
void drawGun();

#endif
