#include "all.h"

// Assets (don't exist at the moment)
//~ void loadTexture() {
    //~ if (!textureLoaded) {
        //~ glGenTextures(1, &texture);
        //~ glBindTexture(GL_TEXTURE_2D, texture);
        
        //~ glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Instructions_width, Instructions_height, 0, GL_RGB, GL_UNSIGNED_BYTE, Instructions);
        //~ glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        //~ glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        
        //~ glBindTexture(GL_TEXTURE_2D, 0);
        
        //~ textureLoaded = 1;
        //~ printf("Loaded instructions\n");
    //~ }
//~ }

//~ _Bool textureLoaded = 0;
//~ GLuint texture;
